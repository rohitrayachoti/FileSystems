#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/init_task.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("ROHIT");
MODULE_DESCRIPTION("Display Process Hierarchy");
MODULE_VERSION("0.01");

// Parameter to track indentation of process
int level = 0;

// structure for process and child
struct task_struct *process;
struct task_struct *pchild;

static void display_hierarchy(struct task_struct *process, int level) {
	struct list_head *list;

	// Iterating the list of all children
        list_for_each(list, &process->children) {
		// Reading child process
                pchild = list_entry(list, struct task_struct, sibling);

		// Printing child process details
		printk(KERN_INFO "%*c%s[%d]\n", level, ' ', pchild->comm, pchild->pid);

		// Recursive call for child process with incremented indentation level
                display_hierarchy(pchild, level + 2);
        }
}

static int __init run_modprocesstree(void) {
        printk(KERN_INFO "ProcessTree: Loading module\n");

	// Iterating the process list
        for(process=current; process!=&init_task; process=process->parent);

	// Printing the root process
        printk(KERN_INFO "%s[%d]\n", process->comm, process->pid);

	// Calling display_hierarchy function to print other processes
        display_hierarchy(process, level + 2);

        return 0;
}

static void __exit exit_modprocesstree(void) {
        printk(KERN_INFO "ProcessTree: Removing module\n");
}

module_init(run_modprocesstree);
module_exit(exit_modprocesstree);
